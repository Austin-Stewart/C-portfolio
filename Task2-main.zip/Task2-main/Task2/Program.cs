﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;

namespace Task2
{
    class Program
    {   //Dictionary that holds salespeople data
        public static Dictionary<int, SalesPerson> Loadpeople()
        {
            Console.WriteLine("Enter number of salespeople to process");
            int salesPeopleNum = Convert.ToInt32((Console.ReadLine()));
            int i = 0;
            //Dictionary to store the data for all sales persons.
            Dictionary<int, SalesPerson> Salespeople = new Dictionary<int, SalesPerson>();
            //Loop to create specified number of salespeople
            while (i < salesPeopleNum)
            { 
                //Allow user to add salespeople to the dictionary
                try
                {
                    Console.WriteLine("\nEnter sales person name [e.g. John]: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter Level [e.g. 1]: ");
                    int level = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Hours Worked [e.g. 10]: ");
                    double hours = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter Sales Amount [e.g. 2000]: ");
                    Double Salesamount = Convert.ToDouble(Console.ReadLine());
                    SalesPerson individual = new SalesPerson(name, level, Salesamount, hours);
                    //add the items to dictionary
                    Salespeople.Add(i, individual);
                    i++;
                }
                catch
                {
                    Console.WriteLine("Try again:");
                }
                
            }
            return Salespeople;


        }
        static void Main(string[] args)
        {
            Dictionary<int, SalesPerson> Salesinfo = Loadpeople();
            int i = 0;
            double grandCommissions = 0;
            double grandHourlyWages = 0;
            double grandBonuses = 0;
            
            for (int j = 0; j < Salesinfo.Count; j++)
            {
                grandCommissions += Salesinfo[j].CalcCommission();
                grandHourlyWages += Salesinfo[j].CalculatePay();
                grandBonuses += Salesinfo[j].CalculateBonus();
                 


            }
            double grandAmountPayedToEmployees = grandCommissions + grandHourlyWages + grandBonuses;
            Console.WriteLine("Total commissions for all salespersons combined:${0}", grandCommissions) ;
            Console.WriteLine("Total hourly wages for all salespersons combined:${0}", grandHourlyWages);
            Console.WriteLine("Total amount payed to all employees combined:${0}", grandAmountPayedToEmployees);
            foreach (var item in Salesinfo)
            {   
                //print the items out (use ToString method).
                Console.WriteLine(item.Value.ToString());     
                    i++;

            }
           


        }
         
        
    }
}
